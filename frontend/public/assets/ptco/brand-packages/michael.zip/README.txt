Michael V. Mendez — Brand package

Extract this ZIP, then open brand-guide.html in your browser.
The assets folder contains the existing artwork in its original formats.
Website: https://michaelvmendez.com
Prepared by Plot Twist Co.
