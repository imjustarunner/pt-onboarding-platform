The Inner Strength Institute — Brand package

Extract this ZIP, then open brand-guide.html in your browser.
The assets folder contains the existing artwork in its original formats.
Website: https://theinnerstrengthinstitute.com
Prepared by Plot Twist Co.
