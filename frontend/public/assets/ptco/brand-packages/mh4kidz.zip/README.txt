MH4Kidz — Brand package

Extract this ZIP, then open brand-guide.html in your browser.
The assets folder contains the existing artwork in its original formats.
Website: https://mh4kidz.org
Prepared by Plot Twist Co.
